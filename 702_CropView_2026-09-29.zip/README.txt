CropView Export · 702
═══════════════════════════
Notes:    —
Session:  2026-09-29T04:18:18.349Z
Exported: 2026-09-29T04:24:43.468Z
Captures: 18

images/  → geocoded JPEGs  {Project}_{ID}_{Timestamp}_{Lat}_{Lon}.jpg
data/    → points GeoJSON (capture locations)
           footprints GeoJSON (FOV ground polygons — use for satellite pixel sampling)
           CSV of all captures

Developed by Somdeep Kundu
RuDRA Lab · C-TARA · IIT Bombay
RGSTC Maharashtra Government Project
https://somdeepkundu.github.io
© 2026 Somdeep Kundu · MIT License