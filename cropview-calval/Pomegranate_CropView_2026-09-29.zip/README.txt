CropView Export · Pomegranate
═══════════════════════════
Notes:    —
Session:  2026-09-29T06:39:22.881Z
Exported: 2026-09-29T06:52:59.508Z
Captures: 17

images/  → geocoded JPEGs  {Project}_{ID}_{Timestamp}_{Lat}_{Lon}.jpg
data/    → points GeoJSON (capture locations)
           footprints GeoJSON (FOV ground polygons — use for satellite pixel sampling)
           CSV of all captures

Developed by Somdeep Kundu
RuDRA Lab · C-TARA · IIT Bombay
RGSTC Maharashtra Government Project
https://somdeepkundu.github.io
© 2026 Somdeep Kundu · MIT License